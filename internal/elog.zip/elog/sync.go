package elog

import (
	"context"
	"encoding/json"
	"sync"

	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/ipfs/boxo/ipld/merkledag"
	"github.com/ipfs/go-cid"
	format "github.com/ipfs/go-ipld-format"
)

type SyncMessage struct {
	Type  string   `json:"type"` // "heads", "want", "block"
	Heads []string `json:"heads,omitempty"`
	CID   string   `json:"cid,omitempty"`
	Data  []byte   `json:"data,omitempty"`
	Links []string `json:"links,omitempty"`
}

type Sync struct {
	log     *EventLog
	client  mqtt.Client
	topic   string
	mu      sync.Mutex
	pending map[cid.Cid]struct{} // блоки которые запросили
}

func NewSync(log *EventLog, client mqtt.Client, topic string) *Sync {
	s := &Sync{
		log:     log,
		client:  client,
		topic:   topic,
		pending: make(map[cid.Cid]struct{}),
	}

	client.Subscribe(topic, 1, s.onMessage)

	return s
}

func (s *Sync) onMessage(_ mqtt.Client, msg mqtt.Message) {
	var m SyncMessage
	if err := json.Unmarshal(msg.Payload(), &m); err != nil {
		return
	}

	ctx := context.Background()

	switch m.Type {
	case "heads":
		s.handleHeads(ctx, m.Heads)

	case "want":
		s.handleWant(ctx, m.CID)

	case "block":
		s.handleBlock(ctx, m)
	}
}

func (s *Sync) handleHeads(ctx context.Context, heads []string) {
	for _, h := range heads {
		c, err := cid.Decode(h)
		if err != nil {
			continue
		}

		// Проверяем есть ли у нас этот блок
		if _, _, err := s.log.Get(ctx, c); err == merkledag.ErrNotProtobuf {
			s.requestBlock(c)
		}
	}

	// Мержим heads
	var cids []cid.Cid
	for _, h := range heads {
		if c, err := cid.Decode(h); err == nil {
			cids = append(cids, c)
		}
	}
	s.log.Merge(cids)
}

func (s *Sync) handleWant(ctx context.Context, cidStr string) {
	c, err := cid.Decode(cidStr)
	if err != nil {
		return
	}

	data, parents, err := s.log.Get(ctx, c)
	if err != nil {
		return
	}

	var links []string
	for _, p := range parents {
		links = append(links, p.String())
	}

	s.publish(SyncMessage{
		Type:  "block",
		CID:   cidStr,
		Data:  data,
		Links: links,
	})
}

func (s *Sync) handleBlock(ctx context.Context, m SyncMessage) {
	c, err := cid.Decode(m.CID)
	if err != nil {
		return
	}

	s.mu.Lock()
	_, isPending := s.pending[c]
	delete(s.pending, c)
	s.mu.Unlock()

	if !isPending {
		return
	}

	// Запрашиваем родителей если нет
	for _, linkStr := range m.Links {
		lc, err := cid.Decode(linkStr)
		if err != nil {
			continue
		}
		if _, _, err := s.log.Get(ctx, lc); err == merkledag.ErrNotProtobuf {
			s.requestBlock(lc)
		}
	}

	// Сохраняем блок через Append с родителями
	// Или напрямую в DAG если структура другая
	s.addBlockDirect(ctx, c, m.Data, m.Links)
}

func (s *Sync) addBlockDirect(ctx context.Context, c cid.Cid, data []byte, links []string) {
	// Импорт блока напрямую в DAG
	node := merkledag.NodeWithData(data)
	for _, linkStr := range links {
		if lc, err := cid.Decode(linkStr); err == nil {
			node.AddRawLink("parent", &format.Link{Cid: lc})
		}
	}
	s.log.DAG().Add(ctx, node)
}

func (s *Sync) requestBlock(c cid.Cid) {
	s.mu.Lock()
	if _, ok := s.pending[c]; ok {
		s.mu.Unlock()
		return
	}
	s.pending[c] = struct{}{}
	s.mu.Unlock()

	s.publish(SyncMessage{
		Type: "want",
		CID:  c.String(),
	})
}

func (s *Sync) BroadcastHeads() {
	heads := s.log.Heads()
	var strs []string
	for _, h := range heads {
		strs = append(strs, h.String())
	}

	s.publish(SyncMessage{
		Type:  "heads",
		Heads: strs,
	})
}

func (s *Sync) publish(m SyncMessage) {
	data, _ := json.Marshal(m)
	s.client.Publish(s.topic, 1, false, data)
}

// Вызывать после Append
func (s *Sync) OnAppend(c cid.Cid) {
	s.BroadcastHeads()
}
