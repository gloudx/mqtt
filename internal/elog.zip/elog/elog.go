package elog

import (
	"context"
	"encoding/json"
	"sync"

	"github.com/ipfs/boxo/blockservice"
	"github.com/ipfs/boxo/exchange/offline"
	"github.com/ipfs/boxo/ipld/merkledag"
	"github.com/ipfs/go-cid"
	"github.com/ipfs/go-datastore"
	blockstore "github.com/ipfs/go-ipfs-blockstore"
	format "github.com/ipfs/go-ipld-format"
)

var headsKey = datastore.NewKey("/eventlog/heads")

type EventLog struct {
	mu    sync.RWMutex
	ds    datastore.Batching
	dag   format.DAGService
	heads map[cid.Cid]struct{}
}

func New(ds datastore.Batching) (*EventLog, error) {
	bs := blockstore.NewBlockstore(ds)
	bsvc := blockservice.New(bs, offline.Exchange(bs))

	l := &EventLog{
		ds:    ds,
		dag:   merkledag.NewDAGService(bsvc),
		heads: make(map[cid.Cid]struct{}),
	}

	if err := l.loadHeads(); err != nil {
		return nil, err
	}

	return l, nil
}

func (l *EventLog) loadHeads() error {
	data, err := l.ds.Get(context.Background(), headsKey)
	if err == datastore.ErrNotFound {
		return nil
	}
	if err != nil {
		return err
	}

	var strs []string
	if err := json.Unmarshal(data, &strs); err != nil {
		return err
	}

	for _, s := range strs {
		if c, err := cid.Decode(s); err == nil {
			l.heads[c] = struct{}{}
		}
	}
	return nil
}

func (l *EventLog) saveHeads() error {
	strs := make([]string, 0, len(l.heads))
	for h := range l.heads {
		strs = append(strs, h.String())
	}
	data, _ := json.Marshal(strs)
	return l.ds.Put(context.Background(), headsKey, data)
}

func (l *EventLog) Append(ctx context.Context, data []byte) (cid.Cid, error) {
	l.mu.Lock()
	defer l.mu.Unlock()

	node := merkledag.NodeWithData(data)

	for head := range l.heads {
		parent, err := l.dag.Get(ctx, head)
		if err != nil {
			return cid.Cid{}, err
		}
		if err := node.AddNodeLink("parent", parent); err != nil {
			return cid.Cid{}, err
		}
	}

	if err := l.dag.Add(ctx, node); err != nil {
		return cid.Cid{}, err
	}

	l.heads = map[cid.Cid]struct{}{node.Cid(): {}}

	if err := l.saveHeads(); err != nil {
		return cid.Cid{}, err
	}

	return node.Cid(), nil
}

func (l *EventLog) Merge(heads []cid.Cid) error {
	l.mu.Lock()
	defer l.mu.Unlock()

	for _, h := range heads {
		l.heads[h] = struct{}{}
	}

	return l.saveHeads()
}

func (l *EventLog) SetHeads(heads []cid.Cid) error {
	l.mu.Lock()
	defer l.mu.Unlock()

	l.heads = make(map[cid.Cid]struct{}, len(heads))
	for _, h := range heads {
		l.heads[h] = struct{}{}
	}

	return l.saveHeads()
}

// Get, Heads, DAG — без изменений

func (l *EventLog) Get(ctx context.Context, c cid.Cid) ([]byte, []cid.Cid, error) {
	l.mu.RLock()
	defer l.mu.RUnlock()

	node, err := l.dag.Get(ctx, c)
	if err != nil {
		return nil, nil, err
	}

	pbn, ok := node.(*merkledag.ProtoNode)
	if !ok {
		return nil, nil, merkledag.ErrNotProtobuf
	}

	var parents []cid.Cid
	for _, link := range pbn.Links() {
		if link.Name == "parent" {
			parents = append(parents, link.Cid)
		}
	}

	return pbn.Data(), parents, nil
}

func (l *EventLog) Heads() []cid.Cid {
	l.mu.RLock()
	defer l.mu.RUnlock()

	result := make([]cid.Cid, 0, len(l.heads))
	for h := range l.heads {
		result = append(result, h)
	}
	return result
}

func (l *EventLog) DAG() format.DAGService {
	return l.dag
}
