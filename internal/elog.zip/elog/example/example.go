package main

import (
	"context"
	"fmt"
	"log"
	"mqtt-http-tunnel/internal/elog"
	"os"
	"os/signal"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"
	// "github.com/ipfs/go-datastore"
	// dssync "github.com/ipfs/go-datastore/sync"
	badger "github.com/ipfs/go-ds-badger4"
)

func main() {
	ctx := context.Background()
	nodeID := os.Getenv("NODE_ID")
	if nodeID == "" {
		nodeID = "node1"
	}

	// Datastore (в проде заменить на badger/leveldb)
	// ds := dssync.MutexWrap(datastore.NewMapDatastore())

	ds, err := badger.NewDatastore("./data", &badger.DefaultOptions)
	if err != nil {
		log.Fatal(err)
	}
	defer ds.Close()

	// EventLog
	l, err := elog.New(ds)
	if err != nil {
		log.Fatal(err)
	}

	// MQTT
	opts := mqtt.NewClientOptions().
		AddBroker("tcp://localhost:1883").
		SetClientID(nodeID).
		SetAutoReconnect(true)

	client := mqtt.NewClient(opts)
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		log.Fatal(token.Error())
	}
	defer client.Disconnect(250)

	// Sync
	sync := elog.NewSync(l, client, "events/mylog")

	// Анонсируем heads при старте
	sync.BroadcastHeads()

	// Периодический анонс heads
	go func() {
		ticker := time.NewTicker(30 * time.Second)
		for range ticker.C {
			sync.BroadcastHeads()
		}
	}()

	// Добавляем события
	go func() {
		for i := 0; ; i++ {
			time.Sleep(5 * time.Second)

			data := fmt.Sprintf("[%s] event %d at %s", nodeID, i, time.Now().Format(time.RFC3339))
			c, err := l.Append(ctx, []byte(data))
			if err != nil {
				log.Printf("append error: %v", err)
				continue
			}

			log.Printf("appended: %s -> %s", c, data)
			sync.OnAppend(c)
		}
	}()

	// Выводим текущие heads
	go func() {
		ticker := time.NewTicker(10 * time.Second)
		for range ticker.C {
			heads := l.Heads()
			log.Printf("current heads: %v", heads)
		}
	}()

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt)
	<-quit

	log.Println("shutting down...")
}
